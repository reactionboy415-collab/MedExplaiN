import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  // Parse JSON request bodies
  app.use(express.json());

  // NoteAI YouTube Info Proxy API
  // Solves browser CORS and header spoofing restrictions (Origin, Referer, User-Agent)
  app.post('/api/youtube-info', async (req, res) => {
    try {
      const { video } = req.body;

      if (!video || typeof video !== 'string') {
        return res.status(400).json({
          success: false,
          error: 'Please provide a valid "video" YouTube URL string in request body.'
        });
      }

      console.log(`[NovaTube Proxy] Fetching YouTube info for: ${video}`);

      const noteaiResponse = await fetch('https://www.noteai.io/api/tools/youtube/info', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'origin': 'https://www.noteai.io',
          'referer': 'https://www.noteai.io/e622/youtube-video-downloader',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
          'accept': 'application/json, text/plain, */*',
          'accept-language': 'en-US,en;q=0.9',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty'
        },
        body: JSON.stringify({ video })
      });

      if (!noteaiResponse.ok) {
        const errorText = await noteaiResponse.text();
        console.error(`[NovaTube Proxy] NoteAI responded with ${noteaiResponse.status}:`, errorText);
        return res.status(noteaiResponse.status).json({
          success: false,
          error: `NoteAI service returned HTTP ${noteaiResponse.status}`,
          details: errorText
        });
      }

      const data = await noteaiResponse.json();
      console.log(`[NovaTube Proxy] Successfully extracted metadata for: "${data?.video_info?.title || 'Unknown Title'}"`);
      return res.json(data);

    } catch (err: any) {
      console.error('[NovaTube Proxy] Error contacting NoteAI:', err);
      return res.status(500).json({
        success: false,
        error: 'Failed to contact NoteAI streaming gateway.',
        message: err?.message || String(err)
      });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Vite development middleware vs Static Production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true'
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[NovaTube] Dev server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
